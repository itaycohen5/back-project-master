package com.dev.controllers;

import com.dev.objects.MatchObject;
import com.dev.objects.TableLeagueRow;
import com.dev.objects.TeamObject;
import com.dev.objects.UserObject;
import com.dev.responses.BasicResponse;
import com.dev.responses.MatchResponse;
import com.dev.responses.UserResponse;
import com.dev.utils.Persist;
import com.dev.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.util.List;


@RestController
public class TestController {

    private final int USERNAME_ALREADY_TAKEN = 1;
    private final int PASSWORD_INCORRECT = 2;
//    private final int USERNAME_ALREADY_TAKEN = 1;
//    private final int USERNAME_ALREADY_TAKEN = 1;

    @Autowired
    public Utils utils;


    @Autowired
    private Persist persist;

    @PostConstruct
    public void init() {
    }


    @RequestMapping
            (value = "/get-matches", method = {RequestMethod.GET, RequestMethod.POST})
    public List<MatchObject> getAllMatches() {
        List<MatchObject> matchObjectList = persist.getMatches();
        return matchObjectList;
    }

    @RequestMapping
            (value = "/get-all-teams", method = {RequestMethod.GET, RequestMethod.POST})
    public List<TeamObject> getAllTeams() {
        List<TeamObject> allTeams = persist.getAllTeams();
        return allTeams;
    }


    @RequestMapping
            (value = "/get-table-league-end-matches", method = {RequestMethod.GET, RequestMethod.POST})
    public List<TableLeagueRow> getTableLeagueEndMatches() {
        List<TeamObject> allTeams = persist.getAllTeams();
        List<MatchObject> matchObjectList = persist.getEndMatches();
        List<TableLeagueRow> tableLeague = utils.calc(allTeams, matchObjectList);
        return tableLeague;
    }

    @RequestMapping //RUNNING MATCHES
            (value = "/get-all-live-matches", method = {RequestMethod.GET, RequestMethod.POST})
    public List<MatchObject> getAllLiveMatch() {
        List<MatchObject> matchObjectList = persist.getLiveMatches();
        return matchObjectList;
    }


    @RequestMapping //END MATCHES + RUNNING MATCHES
            (value = "/get-full-table-league", method = {RequestMethod.GET, RequestMethod.POST})
    public List<TableLeagueRow> getFullTableLeague() {
        List<TeamObject> teams = persist.getAllTeams();
        List<MatchObject> matchObjectList = persist.getMatches();
        List<TableLeagueRow> tableLeagueRowList = utils.calc(teams, matchObjectList);
        return tableLeagueRowList;
    }


    @RequestMapping //ADD MATCH TO DB (RESULT 0 - 0)
            (value = "/add-match", method = {RequestMethod.POST})
    public MatchResponse addMatch(String team1, String team2,UserObject userIdThatUpdate) {
        MatchResponse matchResponse = new MatchResponse();
        List<TeamObject> teamObjectList = persist.getAllTeams();
        TeamObject teamN1 = utils.getTeamByName(team1, teamObjectList);
        TeamObject teamN2 = utils.getTeamByName(team2, teamObjectList);
        MatchObject matchObject = persist.addMatch(teamN1, teamN2,userIdThatUpdate);
        if (matchObject == null) {
            matchResponse.setSuccess(false);
            matchResponse.setErrorCode(3);
            return matchResponse;
        }else {
            matchResponse.setSuccess(true);
            matchResponse.setErrorCode(null);
            matchResponse.setUserObject(userIdThatUpdate);
        }
        return matchResponse;
    }

    @RequestMapping // UPDATE THE MATCH BY GOALS
            (value = "/update-match", method = {RequestMethod.POST})
    public MatchResponse updateMatch(int matchId, int goalsTeam1, int goalsTeam2) {
        MatchResponse matchResponse = new MatchResponse();
        if (goalsTeam1 < 0 || goalsTeam2 < 0) {
            matchResponse.setSuccess(false);
            matchResponse.setErrorCode(2);
            matchResponse.setMatchId(matchId);
            return matchResponse;
        }
        MatchObject matchObject = persist.findMatchById(matchId);
        if (utils.checkIfMatchIsRunning(matchObject)) {
            persist.updateMatch(matchId, goalsTeam1, goalsTeam2);
            matchResponse.setSuccess(true);
            matchResponse.setErrorCode(0);
            matchResponse.setMatchId(matchId);
        } else {
            matchResponse.setSuccess(false);
            matchResponse.setErrorCode(1);
            matchResponse.setMatchId(matchId);
        }
        return matchResponse;
    }

    @RequestMapping // FINISH THE MATCH
            (value = "/finish-match", method = {RequestMethod.GET, RequestMethod.POST})
    public void finishMatch(int matchId) {
        persist.finishedMatch(matchId);
    }

    @RequestMapping //CREAT-ACCOUNT
            (value = "/create-account", method = {RequestMethod.POST})
    public UserResponse addUser(String username, String password) {
        UserResponse userResponse;
        UserObject newUser = null;
        if (utils.validateUserName(username)) {
            if (utils.validatePassword(password)) {
                if (persist.usernameAvailable(username)) {
                    String token = utils.createHash(username, password);
                    newUser = persist.addUser(username, token);
                }
            }
        }
        userResponse = new UserResponse(true, null, newUser);
        return userResponse;
    }

    @RequestMapping // SIGN-IN
            (value = "/sign-in", method = {RequestMethod.GET, RequestMethod.POST})
    public BasicResponse signIn(String username, String password) {
        BasicResponse basicResponse = null;
        String token = utils.createHash(username, password);
        token = persist.getUserByCreds(username, token);
        if (token == null) {
            if (persist.usernameAvailable(username)) { // there is no such username
                basicResponse = new BasicResponse(false, 1);
            } else {
                basicResponse = new BasicResponse(false, 2);
            }
        } else {
            UserObject user = persist.getUserByToken(token);
            basicResponse = new UserResponse(true, null, user);
        }
        return basicResponse;
    }
}